# Puissance 4

[Related post (fr)](http://www.synbioz.com/blog/2011/12/20/jouons_un_peu_avec_les_websocket)

## Install

- node.js
- npm
- socket.io: npm install -g socket.io

## TODO

- Add diagonal victories
